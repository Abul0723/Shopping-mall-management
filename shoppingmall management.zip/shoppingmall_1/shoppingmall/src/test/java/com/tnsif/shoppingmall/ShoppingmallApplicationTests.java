package com.tnsif.shoppingmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallApplicationTests {

	@Test
	void contextLoads() {
	}

}
